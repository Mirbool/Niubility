﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class CoroutineManager
{
    private static CoroutineManager _instance = null;

    public static CoroutineManager Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new CoroutineManager();
            }
            return _instance;
        }
    }

    private LinkedList<IEnumerator> coroutineList = new LinkedList<IEnumerator>();

    public void StartCoroutine(IEnumerator ie)
    {
        coroutineList.AddLast(ie);
    }

    public void StopCoroutine(IEnumerator ie)
    {
        try
        {
            coroutineList.Remove(ie);
        }
        catch (Exception e) { Console.WriteLine(e.ToString()); }
    }

    public void UpdateCoroutine()
    {
        var node = coroutineList.First;
        while(node != null)
        {
            IEnumerator ie = node.Value;
            bool ret = true;
            if(ie.Current is IWait)
            {
                IWait wait = (IWait)ie.Current;
                if (wait.Tick())
                {
                    ret = ie.MoveNext();
                }
            }
            else
            {
                ret = ie.MoveNext();
            }
            if (!ret)
            {
                coroutineList.Remove(node);
            }
            node = node.Next;
        }
    }

}

