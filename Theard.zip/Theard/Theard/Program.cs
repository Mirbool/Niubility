﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Theard
{
    class Program
    {
        static void Main(string[] args)
        { 
            Console.WriteLine("啊啊啊啊!");

            var t1 = Test1();
            var t2 = Test2();
            CoroutineManager.Instance.StartCoroutine(t1);
            CoroutineManager.Instance.StartCoroutine(t2);

            //模拟Update
            while (true)
            {
                Thread.Sleep(Time.deltaMilliseconds);
                CoroutineManager.Instance.UpdateCoroutine();
            }

        }
        static IEnumerator Test1()
        {
            Console.WriteLine("start test 1");
            yield return new WaitForSeconds(5);
            Console.WriteLine("after 5 seconds");
            yield return new WaitForSeconds(5);
            Console.WriteLine("after 10 seconds");
        }
        static IEnumerator Test2()
        {
            Console.WriteLine("start test 2");
            yield return new WaitForFrames(500);
            Console.WriteLine("after 500 frames");
        }
    }
}
